touch individual
touch joint
touch admin
gcc client.c -o client
gcc server.c -o server
